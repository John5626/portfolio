#pragma once
bool nao_enforcou();