#include <string>
#include <iostream>
#include "letra_existe.hpp"
#include <map>
#include <vector>

extern std::map<char, bool> chutou;
extern std::vector<char> chutes_errados;

void chutar_letra(std::string palavra_secreta){
    char chute;
    std::cout << "Chute: "; std::cin >> chute;
        
    chutou[chute] = true;

    std::cout << "Seu chute foi " << chute << std::endl;
    if(letra_existe(palavra_secreta, chute)){
        std::cout << "Voce acertou. Seu chute esta na palavra secreta\n" << std::endl;
    } 
    else{
        std::cout << "Voce errou. Seu chute nao esta na palavra secreta\n" << std::endl;
        chutes_errados.push_back(chute); //adiciona no final da lista
    }
    
}