#pragma once
#include <string>
bool letra_existe(std::string palavra_secreta, char chute);