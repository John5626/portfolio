#pragma once
#include <vector>
#include <string>


std::vector<std::string> ler_arquivo();