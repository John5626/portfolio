#pragma once
#include <string>
void game_over(std::string palavra_secreta);