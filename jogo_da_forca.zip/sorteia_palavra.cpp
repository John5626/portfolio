#include <vector>
#include <ctime>
#include "ler_arquivo.hpp"


std::string sorteia_palavra(){
    std::vector<std::string> palavras = ler_arquivo();

    short i_sorteado = rand() % (palavras.size());

    return palavras[i_sorteado];
}
