#include <vector>
#include <string>
#include <iostream>
#include <fstream>

bool nova_palavra(std::vector<std::string> nova){
    std::ofstream file;
    file.open("palavras.txt");
    if(!file.is_open()){
        std::cout << "ERRO" << std::endl;
        exit(0);
    }

    file << nova.size() << std::endl;

    for(std::string palavra : nova){
        file << palavra << std::endl;
    }

    file.close();

    return true;
}