#include <string>

extern std::string palavra_secreta;

bool letra_existe(std::string palavra_secreta, char chute){
    int cont = 0;
    //cout << "Posicao: "; 
   
    for(char letra : palavra_secreta){
        if(chute == letra){
            //cout << i << " ";
            cont++;
        }

    }

    if(cont != 0)
        return true;
    else return false;
}