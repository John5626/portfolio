#include <iostream>
#include <string>
#include <map>

extern std::map<char, bool> chutou;

void exibir_palavra(std::string palavra_secreta){
    for(char letra : palavra_secreta){
            if(chutou[letra]){
                std::cout << letra << " ";
            }
            else{
                std::cout << "_ ";
            }
        }
        std::cout << std::endl; 
}