#pragma once
#include <vector>
#include <string>


bool nova_palavra(std::vector<std::string> nova);