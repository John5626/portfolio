#include <string>
#include <map>
#include <iostream>

#include "letra_existe.hpp"
#include "ler_arquivo.hpp"
#include "sorteia_palavra.hpp"
#include "cabecalho.hpp"
#include "exibir_wrongs.hpp"
#include "exibir_palavra.hpp"
#include "nao_acertou.hpp"
#include "nao_enforcou.hpp"
#include "chutar_letra.hpp"
#include "nova_palavra.hpp"
#include "game_over.hpp"

using namespace std;

map<char, bool> chutou;
vector<char> chutes_errados;

int main(){

    cabecalho();

    string palavra_secreta = sorteia_palavra();
    //cout << palavra_secreta << endl;
    
    while(nao_acertou(palavra_secreta) && nao_enforcou()){
        exibir_wrongs();
        exibir_palavra(palavra_secreta);
        chutar_letra(palavra_secreta);

        cout << endl;
    }

    game_over(palavra_secreta);
}













