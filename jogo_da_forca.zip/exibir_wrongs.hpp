#pragma once
void exibir_wrongs();