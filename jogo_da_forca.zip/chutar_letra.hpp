#pragma once
#include <string>

void chutar_letra(std::string palavra_secreta);