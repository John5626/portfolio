#include <iostream>
#include "nao_acertou.hpp"
#include "nova_palavra.hpp"
#include "ler_arquivo.hpp"
#include "game_over.hpp"

void game_over(std::string palavra_secreta){
    std::cout << "FIM DE JOGO!" << std::endl;
    if(nao_acertou(palavra_secreta)){
        std::cout << "YOU'RE A LOSER! TRY AGAIN, MOTHER FUCKER" << std::endl;
    }
    else std::cout << "Parabens! Voce acertou!" << std::endl;

    std::cout << "A palavra secreta era: " << palavra_secreta << std::endl;

    std::cout << std::endl << "Deseja adicionar uma nova palavra ao Jogo da Forca?" << std::endl;
    std::cout << "(S) Sim   (N) Nao  ";
    char c; std::cin >> c;
    if(c == 'S' || c == 's'){
        std::vector<std::string> nova = ler_arquivo();

        while(1){
            std::cout << "Digite a palavra (EM MAIUSCULO): ";
            std::string palavra;
            std::cin >> palavra;
            nova.push_back(palavra);
            std::cout << "Deseja adicionar outra? (S/N) ";
            std::cin >> c;

            if(c == 'N' || c == 'n')
                break;             

        }

        if(nova_palavra(nova)){
                std::cout << "Palavras adicionadas. " << std::endl;

        }
        else std::cout << "Falha na insercao" << std::endl;
    }         

}