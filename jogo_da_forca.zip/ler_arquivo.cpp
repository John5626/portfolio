#include <fstream>
#include <vector>
#include <string>
#include <iostream>
#include <time.h>
#include "ler_arquivo.hpp"

std::vector<std::string> ler_arquivo(){
    std::ifstream file; file.open("palavras.txt");

    if(!file.is_open()){
        std::cout << "arquivo nao encontrado" << std::endl;
        exit(0);
    }
    
    srand(time(NULL));
    int quant_palavras;
    file >> quant_palavras;

    std::cout << "Palavras: " << quant_palavras << std::endl;

    std::vector<std::string> palavras_arq;
    for(int i = 0; i < quant_palavras; i++){
        std::string palavra;
        file >> palavra;
        palavras_arq.push_back(palavra);
    }

    file.close();

    return palavras_arq;
}