#pragma once
#include <string>

void exibir_palavra(std::string palavra_secreta);
