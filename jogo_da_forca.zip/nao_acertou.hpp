#pragma once
#include <string>

bool nao_acertou(std::string palavra_secreta);