#include <iostream>

void cabecalho(){
    std::cout << "******************" << std::endl;
    std::cout << "*  JOGO DA FORCA *" << std::endl;
    std::cout << "******************" << std::endl;
    std::cout << std::endl;

}