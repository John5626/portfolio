package app.screenmatch.modelos;

public record TituloOmdb(String response, String type, String title, String year, String runtime, String director,
                         String totalseasons, String imdbRating) {

}
