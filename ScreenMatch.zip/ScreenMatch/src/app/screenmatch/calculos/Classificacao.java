package app.screenmatch.calculos;

public interface Classificacao {
    int getClassificacao();
}
